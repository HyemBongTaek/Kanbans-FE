import { createSlice } from "@reduxjs/toolkit";
import { getKanbanBoard } from "../Async/kanbanboard";

const KanbanBoardSlice = createSlice({
  name: "kanbanBoard",
  initialState: {
    kanbans: [],
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(getKanbanBoard.fulfilled, (state, action) => {
      state.kanbans = action.payload.data.board;
    });
  },
});

export default KanbanBoardSlice;
