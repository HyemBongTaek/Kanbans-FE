import { createAsyncThunk } from "@reduxjs/toolkit";
import Apis from "../apis";

export const getKanbanBoard = createAsyncThunk(
  "kanban/getKanbanBoard",
  async ({ projectId }) => {
    try {
      const res = await Apis({
        url: `/board/${projectId}`,
        method: "GET",
      });
      if (res.data.ok) {
        console.log("데이터", res.data);
        return { data: res.data };
      }
    } catch (err) {
      console.log(err);
      return false;
    }
  }
);
