import React from "react";

const CardDetailLeft = () => {
  return (
    <div>
      <div>헹구</div>
    </div>
  );
};

export default CardDetailLeft;
