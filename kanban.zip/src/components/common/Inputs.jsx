import React from "react";

const Inputs = () => {
  return (
    <div>
      <div>헹구</div>
    </div>
  );
};

export default Inputs;
