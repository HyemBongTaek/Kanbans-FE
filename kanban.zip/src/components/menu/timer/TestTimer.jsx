import React from "react";

const TestTimer = () => {
  return (
    <div>
      <div>확인좀해봅시다.</div>
    </div>
  );
};

export default TestTimer;
