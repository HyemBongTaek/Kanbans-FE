import React from "react";
import "./style/_LoadingSpiner.scss";

const LoadingSpinner = () => {
  return <div className="loader" />;
};

export default LoadingSpinner;
