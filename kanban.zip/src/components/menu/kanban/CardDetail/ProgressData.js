const ProgressData = {
  progress: [
    { id: "progress-1", content: "하나둘", checked: true },
    { id: "progress-2", content: "셋넷", checked: false },
    { id: "progress-3", content: "다섯", checked: false },
    { id: "progress-4", content: "여섯", checked: true },
    { id: "progress-5", content: "일곱여덟", checked: true },
  ],
};

export default ProgressData;
