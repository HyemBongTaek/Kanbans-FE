import React from "react";
import Timers from "../../components/menu/timer/Timers";

const Timer = () => {
  return <Timers />;
};

export default Timer;
